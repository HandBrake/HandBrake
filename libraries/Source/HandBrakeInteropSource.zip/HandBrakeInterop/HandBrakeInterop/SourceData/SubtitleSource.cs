﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HandBrake.SourceData
{
	public enum SubtitleSource
	{
		VobSub,
		SRT,
		CC608,
		CC708,
		UTF8,
		TX3G,
		SSA
	}
}
