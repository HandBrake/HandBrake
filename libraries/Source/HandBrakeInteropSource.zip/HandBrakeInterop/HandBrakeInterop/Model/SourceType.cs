﻿namespace HandBrake.Interop
{
	public enum SourceType
	{
		None = 0,
		File,
		VideoFolder,
		Dvd
	}
}