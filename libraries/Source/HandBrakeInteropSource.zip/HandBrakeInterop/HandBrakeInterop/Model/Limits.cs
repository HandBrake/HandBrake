﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HandBrake.Interop
{
	public class Limits
	{
		public int Low { get; set; }

		public int High { get; set; }
	}
}
