﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HandBrake.Interop
{
	public enum Deinterlace
	{
		Off = 0,
		Fast,
		Slow,
		Slower,
		Custom
	}
}
